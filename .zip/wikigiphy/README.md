# Wikigiphy

Wikisearch has been relegated to a sub module



This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.2.2.
